Hi ! THe following are the explainations of the files 

- CH24M571-question2Logs-Server.log - log file for the question 2 after running from server 
- mainfile.log - log file from running file in local 
- mainQ2.py - Python file that was run in server to generate logs 
- orca_q4.py - Python file for running questions 3 and 4 (bigdl)
- q3_ch24m571.log - log file generated locally after running the above python file 
- main.ipynb - Jupyternotebook with the illustration of data 

All of these codes are uploaded to github at : https://github.com/aymuos/masters-practise-repo/tree/main/TERM3/AI_at_Scale/Assignments/Assignment3_4