import os
import json
import numpy as np
import itertools


import subprocess
import sys

try:
    import torch
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "torch"])
    
import torch

# Define the discrete action space exactly as in training
ACTION_VALUES = list(range(0, 101, 10))
ALL_ACTIONS = list(itertools.product(ACTION_VALUES, repeat=3))

class RLAgent:
    def __init__(self):


        # Load model parameters saved as JSON in model.txt
        current_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(current_dir, "model_dqn_best.pt")
        print(f"Loading model parameters from {model_path}")

        self.model_params = torch.load(model_path)
        print("Model parameters loaded successfully.")



        # Extract weights and biases for each linear layer as numpy arrays
        # Note: shape in PyTorch is (out_features, in_features), need correct transpose in np.dot
        self.W1 = np.array(self.model_params['fc1.weight'])  # shape (128, input_dim)
        self.b1 = np.array(self.model_params['fc1.bias'])    # shape (128,)
        self.W2 = np.array(self.model_params['fc2.weight'])  # shape (128, 128)
        self.b2 = np.array(self.model_params['fc2.bias'])    # shape (128,)
        self.W3 = np.array(self.model_params['out.weight'])  # shape (N_ACTIONS, 128)
        self.b3 = np.array(self.model_params['out.bias'])    # shape (N_ACTIONS,)

    def _relu(self, x):
        return np.maximum(0, x)

    def act(self, obs):
        x = np.array(obs, dtype=np.float32)
        # Forward pass with manual matrix multiplications and ReLUs
        x = np.dot(self.W1, x) + self.b1      # Layer 1
        x = self._relu(x)
        x = np.dot(self.W2, x) + self.b2      # Layer 2
        x = self._relu(x)
        x = np.dot(self.W3, x) + self.b3      # Output layer

        action_idx = int(np.argmax(x))
        # Return action as a tuple of three discrete values
        return list(ALL_ACTIONS[action_idx])

    def run_policy(self, obs):
        return self.act(obs)
